/**
 * WSA Social - Facebook Group Auto-Publisher Content Script
 * Executes zero-click automated sharing inside Facebook Group feeds.
 */

(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__WSA_CONTENT_INJECTED__) return;
  window.__WSA_CONTENT_INJECTED__ = true;

  console.log('🚀 WSA Social Auto-Share Content Script loaded.');

  let hudElement = null;

  // Create floating HUD
  function createHud(initialText = 'WSA Auto-Pilot Initializing...') {
    if (document.getElementById('wsa-hud-card')) return;

    hudElement = document.createElement('div');
    hudElement.id = 'wsa-hud-card';
    hudElement.style.cssText = `
      position: fixed;
      top: clamp(10px, 2vh, 22px);
      right: clamp(10px, 2vw, 24px);
      z-index: 999999;
      background: #0f172a;
      color: #f8fafc;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      font-size: clamp(11.5px, 1.1vw, 13px);
      padding: clamp(10px, 1.2vw, 14px) clamp(12px, 1.5vw, 18px);
      border-radius: clamp(9px, 1.2vw, 13px);
      border: 1.5px solid #3b82f6;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      width: clamp(280px, 88vw, 370px);
      max-width: 92vw;
      box-sizing: border-box;
      transition: all 0.3s ease;
      display: flex;
      flex-direction: column;
      gap: 6px;
    `;

    hudElement.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #334155; padding-bottom:6px;">
        <span style="font-weight:800; font-size:clamp(12px, 1.2vw, 13.5px); color:#60a5fa; display:flex; align-items:center; gap:6px;">
          <span>⚡ WSA Auto-Pilot</span>
        </span>
        <span id="wsa-hud-badge" style="background:#1d4ed8; color:#fff; font-size:clamp(9px, 0.95vw, 10.5px); font-weight:700; padding:2px 7px; border-radius:10px;">WORKING</span>
      </div>
      <div id="wsa-hud-status" style="font-weight:600; color:#e2e8f0; font-size:clamp(11px, 1.1vw, 12.5px); line-height:1.4;">${initialText}</div>
    `;

    document.body.appendChild(hudElement);
  }

  function updateHud(statusText, badge = null, badgeBg = null) {
    if (!hudElement) createHud(statusText);
    const sEl = document.getElementById('wsa-hud-status');
    const bEl = document.getElementById('wsa-hud-badge');
    if (sEl) sEl.innerHTML = statusText;
    if (badge && bEl) {
      bEl.innerText = badge;
      if (badgeBg) bEl.style.background = badgeBg;
    }
  }

  // Helper sleep
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // Initialize and check if current page matches an active task
  async function init() {
    // Wait for DOM to stabilize
    await sleep(2000);

    chrome.runtime.sendMessage({ action: 'GET_ACTIVE_TASK' }, async (response) => {
      if (!response || !response.task) {
        // No active task for this tab
        return;
      }

      const task = response.task;
      const currentUrl = window.location.href.toLowerCase();

      // Flow 1: Multi-Profile Auto-Like on Post or Reel
      if (task.type === 'AUTO_LIKE') {
        console.log(`👍 WSA Auto-Like: Processing task for "${task.profile_name}" (${task.index}/${task.total})`, task);
        createHud(`👍 Auto-Liker: Preparing to like as <b>${task.profile_name}</b> (${task.index}/${task.total})...`);
        try {
          await executeAutoLikeTask(task);
        } catch (err) {
          console.error('WSA Auto-Like Execution Error:', err);
          updateHud(`⚠️ Auto-Like Note: ${err.message}`, 'FINISHED', '#f59e0b');
          chrome.runtime.sendMessage({
            action: 'LIKE_TASK_COMPLETED',
            result: {
              success: false,
              profile_name: task.profile_name,
              error: err.message
            }
          });
        }
        return;
      }

      // Flow 2: Zero-Click Group Sharing (Target Facebook Group Feed)
      const taskGroupUrl = (task.group_url || '').toLowerCase();
      if (!currentUrl.includes('facebook.com/groups/')) {
        return;
      }

      console.log('🎯 WSA Auto-Pilot: Processing Task #' + task.id, task);
      createHud(`Preparing share for <b>${task.group_name}</b> as <i>${task.sender_name}</i>...`);

      try {
        await executeGroupShare(task);
      } catch (err) {
        console.error('WSA Auto-Pilot Execution Error:', err);
        updateHud(`⚠️ <b>Execution Paused:</b> ${err.message}<br><small style="color:#cbd5e1;">Tab band nahi kiya gaya hai taaki aap manually check kar sakein.</small>`, 'PAUSED', '#ef4444');
        chrome.runtime.sendMessage({
          action: 'TASK_COMPLETED',
          result: {
            queue_id: task.id,
            status: 'failed',
            shared_post_url: task.group_url,
            error_message: err.message
          }
        });
      }
    });
  }

  // Find Composer Box on Facebook Group Feed
  async function findComposerTrigger() {
    for (let attempts = 0; attempts < 15; attempts++) {
      // 1. Selector strategy: aria-labels
      let btn = document.querySelector('div[aria-label*="Write something"][role="button"]') ||
                document.querySelector('div[aria-label*="Create a public post"][role="button"]') ||
                document.querySelector('div[aria-label*="Write something..."]') ||
                document.querySelector('div[aria-label*="Create a post"]');

      if (btn) return btn;

      // 2. Text matching strategy
      const allButtons = document.querySelectorAll('div[role="button"][tabindex="0"]');
      for (const b of allButtons) {
        const text = (b.innerText || '').trim();
        if (
          text.includes('Write something...') ||
          text.includes('Write something to') ||
          text.includes('Create a public post') ||
          text.includes("What's on your mind")
        ) {
          return b;
        }
      }

      // 3. Spans with text
      const allSpans = document.querySelectorAll('span');
      for (const span of allSpans) {
        const text = (span.innerText || '').trim();
        if (text === 'Write something...' || text === 'Create a public post…' || text.startsWith('Write something to')) {
          const parentBtn = span.closest('div[role="button"]');
          if (parentBtn) return parentBtn;
          return span;
        }
      }

      await sleep(1000);
    }
    return null;
  }

  // Find Post Dialog (searches specifically for the Create Post modal)
  async function findPostDialog(maxAttempts = 20) {
    for (let i = 0; i < maxAttempts; i++) {
      const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]'));
      
      // Check from newest to oldest (dialogs are usually appended at the end of DOM)
      for (let j = dialogs.length - 1; j >= 0; j--) {
        const d = dialogs[j];
        const rect = d.getBoundingClientRect();
        if (rect.width > 200 && rect.height > 150) {
          const text = (d.innerText || '');
          if (
            text.includes('Create post') ||
            text.includes('Create a public post') ||
            text.includes('Add to your post') ||
            text.includes("What's on your mind") ||
            d.querySelector('[aria-label="Post"]') ||
            d.querySelector('[aria-label*="Create a public post"]') ||
            d.querySelector('[contenteditable="true"]') ||
            d.querySelector('[role="textbox"]')
          ) {
            return d;
          }
        }
      }

      await sleep(500);
    }
    return null;
  }

  // Find the text input/contenteditable inside the modal dialog (rock-solid & multi-strategy)
  async function findEditor(dialog) {
    const candidateSelectors = [
      '[contenteditable="true"][role="textbox"]',
      '[contenteditable="true"]',
      '[role="textbox"]',
      '[data-lexical-editor="true"]',
      '[aria-label*="Create a public post"]',
      '[aria-label*="What\'s on your mind"]',
      '[aria-label*="Write something"]',
      '[data-placeholder*="Create a public post"]',
      '[aria-placeholder*="Create a public post"]'
    ];

    for (let attempt = 0; attempt < 25; attempt++) {
      // Strategy 1: Search inside the passed dialog
      if (dialog) {
        for (const sel of candidateSelectors) {
          const el = dialog.querySelector(sel);
          if (el) {
            console.log(`✅ WSA: Found editor in dialog via '${sel}'`, el);
            return el;
          }
        }
      }

      // Strategy 2: Search inside ANY div[role="dialog"] (100% modal-scoped, never the background feed!)
      for (const sel of candidateSelectors) {
        const el = document.querySelector(`div[role="dialog"] ${sel}`);
        if (el) {
          console.log(`✅ WSA: Found editor in role=dialog via '${sel}'`, el);
          return el;
        }
      }

      // Strategy 3: Click the placeholder text inside the modal to mount / focus Lexical
      const scope = dialog || document.querySelector('div[role="dialog"]');
      if (scope) {
        const textNodes = Array.from(scope.querySelectorAll('span, p, div'));
        const placeholder = textNodes.find(el => {
          const t = (el.innerText || '').trim();
          return (
            t === 'Create a public post...' ||
            t.startsWith('Create a public post') ||
            t.startsWith("What's on your mind") ||
            t.startsWith('Write something')
          );
        });

        if (placeholder) {
          placeholder.click();
          await sleep(350);
        } else {
          // Click center-upper region of modal where typing box lives
          const rect = scope.getBoundingClientRect();
          if (rect.width > 200 && rect.height > 150) {
            const clickTarget = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height * 0.35);
            if (clickTarget && scope.contains(clickTarget)) {
              clickTarget.click();
              await sleep(350);
            }
          }
        }

        // Strategy 4: Check if document.activeElement is now focused inside a modal
        if (document.activeElement && document.activeElement.closest('div[role="dialog"]')) {
          const act = document.activeElement;
          if (act.isContentEditable || act.getAttribute('role') === 'textbox' || act.hasAttribute('contenteditable')) {
            console.log('✅ WSA: Found editor via activeElement inside dialog', act);
            return act;
          }
        }
      }

      await sleep(400);
    }

    return null;
  }

  // Viral / Engaging Keywords Pool (Clean keywords without hashtags)
  const VIRAL_KEYWORDS_POOL = [
    'Watch Reel',
    'Must Watch',
    'Trending Reel',
    'Viral Video',
    'Check This Out',
    'Watch Full Reel',
    'Trending Now',
    'Special Highlight',
    'Top Reel',
    'Amazing Video'
  ];

  function getViralKeyword() {
    const idx = Math.floor(Math.random() * VIRAL_KEYWORDS_POOL.length);
    return VIRAL_KEYWORDS_POOL[idx];
  }

  // Format post content: Caption -> 1 Keyword -> GAP (blank line) -> Intact Link URL
  function buildFormattedPostText(caption, keyword, postUrl) {
    const parts = [];
    const cleanCap = (caption || '').trim();
    if (cleanCap) {
      parts.push(cleanCap);
    }
    if (keyword) {
      parts.push(keyword);
    }
    if (postUrl) {
      // Adding postUrl with double newline creates a clean gap before the link
      parts.push(postUrl.trim());
    }
    return parts.join('\n\n');
  }

  // Simulate realistic human typing character by character
  async function typeHumanKeystrokes(editor, text) {
    editor.focus();
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      try {
        editor.dispatchEvent(new KeyboardEvent('keydown', { key: char, code: char === ' ' ? 'Space' : `Key${char.toUpperCase()}`, bubbles: true }));
        document.execCommand('insertText', false, char);
        editor.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          cancelable: true,
          inputType: 'insertText',
          data: char
        }));
        editor.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
      } catch (e) {
        try { document.execCommand('insertText', false, char); } catch (err) {}
      }
      // Natural typing delay: 50ms to 130ms per character
      const delay = Math.floor(Math.random() * (130 - 50 + 1)) + 50;
      await sleep(delay);
    }
  }

  // Detect if Facebook has finished generating the rich Reel / Link Preview card
  function detectFacebookPreviewCard(dialog) {
    const scope = dialog || document.querySelector('div[role="dialog"]');
    if (!scope) return { detected: false, reason: 'Dialog not found' };

    // 1. Check for wide preview thumbnail image (excluding user avatars which are <= 45px)
    const images = Array.from(scope.querySelectorAll('img'));
    for (const img of images) {
      const rect = img.getBoundingClientRect();
      const src = (img.src || '').toLowerCase();
      if (rect.width >= 90 && rect.height >= 50) {
        if (
          src.includes('fbcdn.net') || 
          src.includes('scontent') || 
          src.includes('external') ||
          src.includes('safe_image')
        ) {
          return {
            detected: true,
            type: 'THUMBNAIL_IMAGE',
            details: `Reel thumbnail verified (${Math.round(rect.width)}x${Math.round(rect.height)}px)`
          };
        }
      }
    }

    // 2. Check for "Remove preview" or attachment close button (Facebook always renders this on link cards)
    const removeButtons = Array.from(scope.querySelectorAll('div[role="button"], button'));
    for (const rb of removeButtons) {
      const label = (rb.getAttribute('aria-label') || rb.innerText || '').toLowerCase();
      if (
        label.includes('remove preview') ||
        label.includes('remove link') ||
        label.includes('remove attachment') ||
        label.includes('clear link preview')
      ) {
        return {
          detected: true,
          type: 'REMOVE_PREVIEW_HANDLE',
          details: `Attachment close handle found ("${label}")`
        };
      }
    }

    // 3. Check for link domain / reel title card
    const textElements = Array.from(scope.querySelectorAll('span, div, h2, h3'));
    for (const el of textElements) {
      const t = (el.innerText || '').trim().toLowerCase();
      if (
        t === 'facebook.com' || 
        t === 'www.facebook.com' || 
        t === 'fb.watch' ||
        t.startsWith('facebook.com/reel')
      ) {
        const rect = el.getBoundingClientRect();
        if (rect.height > 8 && rect.top > 80) {
          return {
            detected: true,
            type: 'DOMAIN_LABEL',
            details: `Facebook Reel card header detected ("${t}")`
          };
        }
      }
    }

    return { detected: false, reason: 'Facebook Reel preview card is still fetching from Meta servers...' };
  }

  // Deep Facebook Diagnostic: Extract exact reason why Post button might be disabled
  function diagnosePostButtonFailure(dialog) {
    const scope = dialog || document.querySelector('div[role="dialog"]');
    const reasons = [];

    // Check 1: Is user joined to this group?
    const bodyText = (document.body.innerText || '').toLowerCase();
    if (bodyText.includes('join group to post') || bodyText.includes('join group')) {
      let joinBtn = document.querySelector('div[aria-label*="Join group" i], div[aria-label*="Join Group"]');
      if (!joinBtn) {
        const buttons = Array.from(document.querySelectorAll('div[role="button"], button'));
        joinBtn = buttons.find(b => {
          const t = (b.innerText || '').trim().toLowerCase();
          return t === 'join group' || t === 'join' || t.startsWith('join');
        });
      }
      if (joinBtn) reasons.push('Account has not joined this group (Join Group button detected)');
    }

    // Check 2: Error banner or warning inside dialog
    if (scope) {
      const dialogText = (scope.innerText || '').toLowerCase();
      if (dialogText.includes('temporarily blocked')) reasons.push('Account is temporarily action-blocked by Facebook');
      if (dialogText.includes('couldn\'t be shared')) reasons.push('Facebook blocked this URL from being shared');
      if (dialogText.includes('something went wrong')) reasons.push('Facebook internal server error: Something went wrong');
      if (dialogText.includes('choose how to interact')) reasons.push('Facebook author switch required before posting');
      if (dialogText.includes('admin approval')) reasons.push('Group requires Admin Approval before posting');
    }

    // Check 3: Preview status
    const preview = detectFacebookPreviewCard(scope);
    if (!preview.detected) {
      reasons.push('Facebook could not generate Reel preview card within the timeout');
    }

    // Check 4: Editor content length
    if (scope) {
      const editor = scope.querySelector('[contenteditable="true"]');
      if (!editor || (editor.innerText || '').trim().length === 0) {
        reasons.push('Editor was detected as empty by Facebook React state');
      }
    }

    return reasons.length > 0 ? reasons.join(' | ') : 'Post button remained locked by Facebook React internal validator';
  }

  // Insert content into modern Lexical / Draft.js editors with human typing/editing simulation
  async function insertTextIntoEditor(editor, text) {
    // 1. Natural pause before typing/pasting (1.2 to 2.5 seconds)
    const initialPause = Math.floor(Math.random() * (2500 - 1200 + 1)) + 1200;
    await sleep(initialPause);

    // 2. Also copy to real OS clipboard for safety backup
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      }
    } catch (e) {
      console.warn('Clipboard write fallback ignored:', e);
    }

    // 3. Focus and activate editor
    editor.focus();
    await sleep(300);
    editor.click();
    await sleep(300);

    // 4. Clear any existing selection
    try {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(editor);
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (e) {}

    // 5. Primary Method: Native-like ClipboardEvent paste with DataTransfer
    let pastedSuccess = false;
    try {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: dt
      });
      editor.dispatchEvent(pasteEvent);
      await sleep(800);

      const curVal = (editor.innerText || editor.textContent || '').trim();
      if (curVal.length > 5) {
        pastedSuccess = true;
        console.log('✅ Text successfully pasted via ClipboardEvent into Lexical editor!');
      }
    } catch (err) {
      console.warn('ClipboardEvent paste attempt error:', err);
    }

    // 6. Fallback Method: Line-by-line insertion preserving paragraphs
    if (!pastedSuccess) {
      console.log('⚠️ Using line-by-line execCommand fallback with variable human cadence...');
      editor.focus();
      const lines = text.split('\n');
      for (let idx = 0; idx < lines.length; idx++) {
        const line = lines[idx];
        if (line.length > 0) {
          try {
            document.execCommand('insertText', false, line);
          } catch (e) {}
        }
        if (idx < lines.length - 1) {
          try {
            document.execCommand('insertParagraph', false);
          } catch (e) {}
          await sleep(Math.floor(Math.random() * 120) + 60);
        }
      }
    }

    // 7. Human Input & Change Event Notification (without modifying or deleting any link text)
    try {
      await sleep(300);
      editor.focus();
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {
      console.warn('Input event notification fallback ignored:', e);
    }

    // 8. Dispatch input & change events so React / Lexical marks form as dirty & ready to submit
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    editor.dispatchEvent(new Event('change', { bubbles: true }));

    return true;
  }

  // Find Facebook Post Button (checks text, aria, Hindi, geometry, with auto-force-enable fallback)
  async function findPostButton(dialog) {
    for (let attempts = 0; attempts < 25; attempts++) {
      // Always query current active dialog in case Facebook re-rendered the modal
      const currentDialog = document.querySelector('div[role="dialog"]') || dialog;
      if (!currentDialog) {
        await sleep(600);
        continue;
      }

      const dialogRect = currentDialog.getBoundingClientRect();
      const allButtons = Array.from(currentDialog.querySelectorAll('div[role="button"], button'));

      let bestCandidate = null;

      // 1. Text & Aria-label matching (Supports English, Hindi, and generic action labels)
      for (const b of allButtons) {
        const ariaLabel = (b.getAttribute('aria-label') || '').trim().toLowerCase();
        const text = (b.innerText || '').trim().toLowerCase();

        // Skip close and utility icon buttons
        if (
          ariaLabel.includes('close') || 
          ariaLabel.includes('photo') || 
          ariaLabel.includes('video') || 
          ariaLabel.includes('tag') || 
          ariaLabel.includes('feeling') ||
          ariaLabel.includes('remove') ||
          text === '✕' ||
          text === 'x'
        ) {
          continue;
        }

        const isMatch = (
          ariaLabel === 'post' ||
          ariaLabel === 'publish' ||
          ariaLabel === 'next' ||
          ariaLabel.includes('post to') ||
          ariaLabel.includes('publish to') ||
          ariaLabel.includes('share') ||
          ariaLabel.includes('submit') ||
          ariaLabel.includes('पोस्ट') ||
          ariaLabel.includes('प्रकाशित') ||
          text === 'post' ||
          text === 'publish' ||
          text === 'next' ||
          text === 'submit' ||
          text.includes('post to') ||
          text.includes('publish') ||
          text.includes('पोस्ट') ||
          b.getAttribute('type') === 'submit'
        );

        if (isMatch) {
          bestCandidate = b;
          const ariaDisabled = b.getAttribute('aria-disabled');
          const isDisabled = ariaDisabled === 'true' || b.hasAttribute('disabled');
          if (!isDisabled) {
            console.log('✅ WSA: Active Post button found by text/aria:', b);
            return b;
          }
        }
      }

      // 2. Geometric Matching: Primary action button in the bottom 35% of modal
      if (!bestCandidate) {
        const bottomButtons = allButtons.filter(b => {
          const r = b.getBoundingClientRect();
          const isInBottomArea = r.top >= dialogRect.top + dialogRect.height * 0.60;
          const isWide = r.width >= 100;
          return isInBottomArea && isWide;
        });

        if (bottomButtons.length > 0) {
          // The lowest button in the modal is the submit button
          bottomButtons.sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);
          bestCandidate = bottomButtons[0];
          const ariaDisabled = bestCandidate.getAttribute('aria-disabled');
          const isDisabled = ariaDisabled === 'true' || bestCandidate.hasAttribute('disabled');
          if (!isDisabled) {
            console.log('✅ WSA: Active Post button found by geometry in footer:', bestCandidate);
            return bestCandidate;
          }
        }
      }

      // 3. If bestCandidate found but disabled by Facebook:
      if (bestCandidate) {
        const editor = currentDialog.querySelector('[contenteditable="true"]');
        if (editor && attempts % 2 === 0) {
          try {
            editor.focus();
            document.execCommand('insertText', false, ' ');
            document.execCommand('delete', false);
            editor.dispatchEvent(new Event('input', { bubbles: true }));
            editor.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (e) {}
        }

        // If after 5 attempts (~3.5s) it remains disabled, force-enable it so post publishes!
        if (attempts >= 5) {
          console.log('⚡ WSA: Force-enabling candidate Post button to submit...', bestCandidate);
          bestCandidate.removeAttribute('disabled');
          bestCandidate.setAttribute('aria-disabled', 'false');
          bestCandidate.style.pointerEvents = 'auto';
          bestCandidate.style.opacity = '1';
          return bestCandidate;
        }
      }

      await sleep(700);
    }

    return null;
  }

  // Check for Admin Approval or Live permalink with strict anti-false-positive checks
  async function detectOutcomeAndPermalink(task, existingPostUrls, preApprovalRequired) {
    let outcomeStatus = 'shared';
    let permalink = null;

    // 1. Wait for modal dialog to submit & close (up to 12 seconds)
    for (let wait = 0; wait < 24; wait++) {
      const activeDialog = document.querySelector('div[role="dialog"]');
      if (!activeDialog) break;

      // Check if Facebook showed an inline error/warning inside the dialog
      const dialogText = (activeDialog.innerText || '').toLowerCase();
      if (
        dialogText.includes('something went wrong') ||
        dialogText.includes('temporarily blocked') ||
        dialogText.includes('restricted from posting') ||
        dialogText.includes('violates our community') ||
        dialogText.includes('couldn\'t be shared')
      ) {
        throw new Error(`Facebook error: ${dialogText.slice(0, 120)}`);
      }

      await sleep(500);
    }

    if (document.querySelector('div[role="dialog"]')) {
      console.warn('⚠️ WSA: Modal dialog did not close.');
      return { status: 'dialog_still_open' };
    }

    // 2. If preApprovalRequired was already declared in the composer modal, it's 100% Pending Approval!
    if (preApprovalRequired) {
      console.log('🟡 WSA: Group composer confirmed post approval is required.');
      return { status: 'pending_approval', postUrl: null };
    }

    // 3. Monitor page for toasts, banners, and pending post widgets (up to 12 seconds)
    for (let i = 0; i < 24; i++) {
      const fullPageText = (document.body.innerText || '').toLowerCase();

      const approvalPhrases = [
        'submitted for admin approval',
        'pending admin approval',
        'sent to admin for review',
        'sent to admin',
        'waiting for approval',
        'pending approval',
        'submitted for approval',
        'requires admin approval',
        'participant approval',
        'will appear after it\'s approved',
        'will appear after it is approved',
        'will be visible after it is approved',
        'admin or moderator must approve',
        'admins must approve',
        'manage pending posts',
        'view pending posts',
        'your post has been submitted',
        'submitted your post',
        'post submitted'
      ];

      const hasPendingPhrase = approvalPhrases.some(phrase => fullPageText.includes(phrase));
      const hasPendingLink = !!document.querySelector('a[href*="/pending_posts"], a[href*="pending_posts"]');
      const urlIsPending = window.location.href.toLowerCase().includes('/pending_posts');

      if (hasPendingPhrase || hasPendingLink || urlIsPending) {
        console.log('🟡 WSA: Admin Approval notice detected!');
        return { status: 'pending_approval', postUrl: null };
      }

      // 4. Look for a BRAND NEW post permalink (NOT present before posting)
      const currentLinks = Array.from(document.querySelectorAll('a[href*="/posts/"], a[href*="/permalink/"], a[href*="/reel/"]'));
      for (const a of currentLinks) {
        const href = a.href || '';
        if (href.includes('/groups/') && (href.includes('/posts/') || href.includes('/permalink/') || href.includes('/reel/'))) {
          // Reject comments, users, and photos
          if (!href.includes('/user/') && !href.includes('/comment/') && !href.includes('comment_id')) {
            const clean = href.split('?')[0];
            // Must be NEW (not in pre-existing snapshot)
            if (!existingPostUrls.has(clean)) {
              permalink = clean;
              console.log('✅ WSA: Verified newly created post permalink:', permalink);
              break;
            }
          }
        }
      }

      if (permalink) {
        return { status: 'shared', postUrl: permalink };
      }

      await sleep(500);
    }

    // Default if dialog closed cleanly, no approval notice, and no new link extracted yet
    return { status: 'shared', postUrl: null };
  }

  // Interactive Manual Post Assist Mode: Kept open on Post button issue or disabled state
  function handleManualPostAssist(task, existingPostUrls, preApprovalRequired, diagReason) {
    return new Promise((resolve) => {
      let isFinalized = false;

      const renderAssistHud = (customNote = '') => {
        const hudContent = `
          <div style="font-weight:700; color:#f59e0b; font-size:clamp(12px, 1.2vw, 13.5px); display:flex; align-items:center; gap:6px;">
            <span>⚠️ Auto-Click Paused — Tab Khula Hai</span>
          </div>
          <div style="font-size:clamp(11px, 1.1vw, 12px); color:#f1f5f9; line-height:1.4; margin:6px 0;">
            Caption & Link modal me taiyar hai. Kripya Facebook modal me <b>Post / प्रकाशित करें</b> button dabayein.<br>
            <span style="color:#94a3b8; font-size:clamp(10px, 1vw, 11px);">
              ${customNote || 'Aapke click karte hi extension Live link ya Pending status save karegi.'}
            </span>
          </div>
          <div style="display:flex; gap:6px; margin-top:4px; flex-wrap:wrap;">
            <button id="wsa-btn-manual-verify" style="flex:1 1 140px; background:#10b981; color:#fff; border:none; padding:clamp(6px, 0.9vw, 8px) clamp(8px, 1vw, 12px); border-radius:6px; font-weight:700; font-size:clamp(11px, 1.1vw, 12px); cursor:pointer; box-shadow:0 2px 5px rgba(0,0,0,0.3);">
              ✓ Maine Post Kar Diya
            </button>
            <button id="wsa-btn-manual-skip" style="background:#475569; color:#f1f5f9; border:none; padding:clamp(6px, 0.9vw, 8px) clamp(8px, 1vw, 10px); border-radius:6px; font-weight:600; font-size:clamp(10.5px, 1vw, 11.5px); cursor:pointer;">
              Skip Task
            </button>
          </div>
        `;
        updateHud(hudContent, 'MANUAL ASSIST', '#f59e0b');
        attachHudListeners();
      };

      const cleanup = () => {
        document.removeEventListener('click', onGlobalClick, true);
        if (pollTimer) clearInterval(pollTimer);
      };

      const triggerOutcomeDetection = async (source) => {
        if (isFinalized) return;
        console.log(`🔍 WSA: Checking outcome triggered by [${source}]...`);
        updateHud('🔄 <b>Post Check Active:</b> Submitting & detecting link / approval status...', 'CHECKING', '#3b82f6');

        try {
          const outcome = await detectOutcomeAndPermalink(task, existingPostUrls, preApprovalRequired);

          if (outcome.status === 'dialog_still_open') {
            console.warn('⚠️ WSA: Dialog still open after click check.');
            renderAssistHud('Modal abhi bhi khula hua hai. Kripya pehle Facebook modal me "Post" dabayein!');
            return;
          }

          // Successfully completed either Live or Pending Approval!
          isFinalized = true;
          cleanup();

          if (outcome.status === 'pending_approval') {
            updateHud('🟡 <b>Pending Admin Approval Recorded!</b><br>Database me pending status update ho gaya. Tab closing in 4s...', 'PENDING', '#eab308');
          } else {
            const linkHtml = outcome.postUrl
              ? `<br><a href="${outcome.postUrl}" target="_blank" style="color:#93c5fd; text-decoration:underline; font-size:11.5px; word-break:break-all;">${outcome.postUrl}</a>`
              : '';
            updateHud(`✅ <b>Post Live Recorded!</b>${linkHtml}<br>Database me live status update ho gaya. Tab closing in 4s...`, 'LIVE POST', '#10b981');
          }

          chrome.runtime.sendMessage({
            action: 'TASK_COMPLETED',
            result: {
              queue_id: task.id,
              status: outcome.status,
              shared_post_url: outcome.postUrl,
              error_message: null
            }
          });

          resolve(outcome);
        } catch (err) {
          console.error('WSA Outcome detection error:', err);
          renderAssistHud(`Error: ${err.message}`);
        }
      };

      const attachHudListeners = () => {
        const verifyBtn = document.getElementById('wsa-btn-manual-verify');
        if (verifyBtn) {
          verifyBtn.onclick = (e) => {
            e.stopPropagation();
            triggerOutcomeDetection('verify_button');
          };
        }
        const skipBtn = document.getElementById('wsa-btn-manual-skip');
        if (skipBtn) {
          skipBtn.onclick = (e) => {
            e.stopPropagation();
            if (isFinalized) return;
            isFinalized = true;
            cleanup();
            updateHud('❌ Task skipped by user. Tab band nahi kiya gaya hai.', 'SKIPPED', '#64748b');
            chrome.runtime.sendMessage({
              action: 'TASK_COMPLETED',
              result: {
                queue_id: task.id,
                status: 'failed',
                shared_post_url: task.group_url,
                error_message: `Skipped by user [${diagReason || 'Post button locked'}]`
              }
            });
            resolve({ status: 'failed' });
          };
        }
      };

      const onGlobalClick = (e) => {
        if (isFinalized) return;
        const target = e.target;
        if (!target) return;

        // If clicked inside Facebook's dialog (e.g. user clicking Post or anything in dialog)
        if (target.closest('div[role="dialog"]')) {
          console.log('👆 WSA: Detected user click inside Facebook dialog. Will verify after 1.5s...');
          setTimeout(() => {
            if (!isFinalized) triggerOutcomeDetection('dialog_click');
          }, 1500);
        }
      };

      document.addEventListener('click', onGlobalClick, true);

      // Also watch if dialog closes automatically in background
      const pollTimer = setInterval(() => {
        if (isFinalized) {
          clearInterval(pollTimer);
          return;
        }
        const activeDlg = document.querySelector('div[role="dialog"]');
        if (!activeDlg) {
          // Dialog was closed!
          console.log('🚪 WSA: Post dialog closed. Triggering outcome detection...');
          clearInterval(pollTimer);
          triggerOutcomeDetection('dialog_closed');
        }
      }, 1200);

      // Render initial HUD
      renderAssistHud();
    });
  }

  // Profile / Sender Page Switcher: Ensure sharing happens as task.sender_name
  async function switchProfileIfNeeded(task, dialog = null) {
    if (!task || !task.sender_name) return false;

    // Normalize sender name: remove " (Page)", " [Page]", etc.
    const rawTarget = task.sender_name.replace(/\s*[\(\[](page|profile)[\)\]]/gi, '').trim();
    if (!rawTarget) return false;
    const cleanTargetLower = rawTarget.toLowerCase();

    console.log(`🔍 WSA Profile Check: Target sender is "${rawTarget}" (ID: ${task.account_external_id || 'N/A'})`);

    const isMatch = (str) => {
      if (!str) return false;
      const s = str.toLowerCase();
      return s.includes(cleanTargetLower) || (task.account_external_id && s.includes(String(task.account_external_id)));
    };

    // Helper: Select option from open dropdown / popover menu
    const selectTargetFromMenu = async () => {
      for (let attempt = 0; attempt < 10; attempt++) {
        // Facebook menus usually use role="menuitem", role="radio", role="menuitemradio", role="option", or clickable divs
        const candidates = Array.from(document.querySelectorAll(
          'div[role="menuitem"], div[role="radio"], div[role="menuitemradio"], div[role="option"], div[role="button"][tabindex="0"], div[role="dialog"] div[tabindex="0"]'
        ));

        for (const el of candidates) {
          const text = (el.innerText || '').toLowerCase();
          const aria = (el.getAttribute('aria-label') || '').toLowerCase();

          if (isMatch(text) || isMatch(aria)) {
            console.log(`🎯 WSA: Found profile switcher option matching "${rawTarget}":`, el);
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            await sleep(300);
            el.click();
            return true;
          }
        }
        await sleep(400);
      }
      return false;
    };

    // 1. If inside modal dialog, check author section
    if (dialog) {
      const dialogLines = (dialog.innerText || '').split('\n').map(l => l.trim()).filter(Boolean);
      const topLines = dialogLines.slice(0, 8);
      const alreadyActive = topLines.some(line => isMatch(line));

      if (alreadyActive) {
        console.log(`✅ WSA: Modal author is already "${rawTarget}".`);
        return true;
      }

      updateHud(`🔄 Checking modal author dropdown for "${rawTarget}"...`);

      // Find author dropdown button inside dialog (near the top)
      const modalRect = dialog.getBoundingClientRect();
      const candidates = Array.from(dialog.querySelectorAll('div[role="button"], button, div[aria-haspopup]'));
      const topButtons = candidates.filter(b => {
        const r = b.getBoundingClientRect();
        return r.top >= modalRect.top && r.top <= modalRect.top + 160 && r.width > 20 && r.height > 15;
      });

      let authorDropdownBtn = topButtons.find(b => {
        const label = (b.getAttribute('aria-label') || b.innerText || '').toLowerCase();
        return (
          label.includes('interact') ||
          label.includes('choose how') ||
          label.includes('switch') ||
          label.includes('posting as') ||
          b.getAttribute('aria-haspopup') === 'menu' ||
          b.getAttribute('aria-haspopup') === 'listbox' ||
          b.getAttribute('aria-haspopup') === 'true'
        );
      });

      // If no explicit aria-haspopup, pick the button with author name or near top
      if (!authorDropdownBtn && topButtons.length > 0) {
        authorDropdownBtn = topButtons.find(b => {
          const t = (b.innerText || '').trim();
          return t.length > 2 && t.length < 50 && !t.includes('Post') && !t.includes('Cancel') && !t.includes('Close');
        });
      }

      if (authorDropdownBtn) {
        console.log('🔄 WSA: Clicking modal author dropdown button...', authorDropdownBtn);
        authorDropdownBtn.click();
        await sleep(800);

        const switched = await selectTargetFromMenu();
        if (switched) {
          updateHud(`✅ Switched post author to "${rawTarget}"!`);
          await sleep(1500);
          return true;
        }
      }
    }

    // 2. Check on the Group page header / feed (outside dialog)
    const pageButtons = Array.from(document.querySelectorAll('div[role="button"], button, div[aria-haspopup]'));
    let groupInteractBtn = pageButtons.find(b => {
      const label = (b.getAttribute('aria-label') || b.innerText || '').toLowerCase();
      return (
        label.includes('interacting as') ||
        label.includes('interact as') ||
        label.includes('choose how to interact') ||
        label.includes('select a profile')
      );
    });

    if (groupInteractBtn) {
      const currentLabel = (groupInteractBtn.getAttribute('aria-label') || groupInteractBtn.innerText || '');
      if (isMatch(currentLabel)) {
        console.log(`✅ WSA: Group is already interacting as "${rawTarget}".`);
        return true;
      }

      console.log('🔄 WSA: Clicking group "Interacting as" button...', groupInteractBtn);
      groupInteractBtn.click();
      await sleep(800);

      const switched = await selectTargetFromMenu();
      if (switched) {
        updateHud(`✅ Switched interacting profile to "${rawTarget}"!`);
        await sleep(1500);
        return true;
      }
    }

    console.log(`ℹ️ WSA: Profile "${rawTarget}" is either active or cannot be switched directly.`);
    return false;
  }

  // ============================================================
  // Multi-Profile Auto-Like Engine on Facebook Posts / Reels
  // ============================================================

  // Find Facebook Like Button on Post or Reel (supports English, Hindi, React states)
  async function findAndClickLikeButton() {
    for (let attempt = 0; attempt < 18; attempt++) {
      const allButtons = Array.from(document.querySelectorAll('div[role="button"], button'));

      // Check if already liked first
      const alreadyLikedBtn = allButtons.find(b => {
        const aria = (b.getAttribute('aria-label') || '').toLowerCase();
        const txt = (b.innerText || '').toLowerCase().trim();
        return (
          b.getAttribute('aria-pressed') === 'true' ||
          aria === 'unlike' ||
          aria.includes('remove reaction') ||
          aria.includes('पसंद वापस') ||
          txt === 'unlike'
        );
      });

      if (alreadyLikedBtn) {
        console.log('👍 WSA: Post/Reel is already liked by current profile.');
        return { success: true, alreadyLiked: true };
      }

      // Look for Like button
      const likeBtn = allButtons.find(b => {
        const aria = (b.getAttribute('aria-label') || '').toLowerCase();
        const txt = (b.innerText || '').toLowerCase().trim();
        const isAriaLike = (
          aria === 'like' ||
          aria === 'like this reel' ||
          aria === 'like this video' ||
          aria === 'like this post' ||
          aria === 'पसंद करें' ||
          aria.includes('like') ||
          aria.includes('पसंद')
        );
        const isTextLike = (txt === 'like' || txt === 'पसंद करें');

        // Filter out utility buttons like "People who reacted like this"
        if (aria.includes('reacted') || aria.includes('see who') || aria.includes('filter')) return false;

        return isAriaLike || isTextLike;
      });

      if (likeBtn) {
        console.log('🎯 WSA: Like button found:', likeBtn);
        likeBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await sleep(600);
        try {
          likeBtn.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
        } catch (e) {}
        likeBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        try {
          likeBtn.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, view: window }));
        } catch (e) {}
        likeBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
        likeBtn.click();
        console.log('✅ WSA: Clicked Like button successfully!');
        return { success: true, alreadyLiked: false };
      }

      await sleep(800);
    }

    return { success: false, reason: 'Like button not located within timeout' };
  }

  // Simulate Natural Human Scrolling & Browsing Cadence for 20-30 seconds
  async function simulateHumanScrollCadence(totalDurationSeconds, updateHudCallback) {
    const startTime = Date.now();
    const endTime = startTime + (totalDurationSeconds * 1000);

    while (Date.now() < endTime) {
      const elapsedSec = Math.floor((Date.now() - startTime) / 1000);
      const remainingSec = Math.max(0, totalDurationSeconds - elapsedSec);

      if (updateHudCallback) {
        updateHudCallback(remainingSec, totalDurationSeconds);
      }

      // Natural human scroll actions: smooth scroll down or up
      const scrollAmount = Math.floor(Math.random() * 220) + 100; // 100px to 320px
      const scrollDirection = Math.random() > 0.3 ? 1 : -1; // 70% down, 30% up
      window.scrollBy({
        top: scrollAmount * scrollDirection,
        left: 0,
        behavior: 'smooth'
      });

      // Pause 3 to 5 seconds between scrolls
      const pauseMs = Math.floor(Math.random() * 2000) + 3000;
      await sleep(Math.min(pauseMs, Math.max(500, endTime - Date.now())));
    }
  }

  // Generate relevant contextual comment tailored to post snippet / topic
  function generateContextualComment(profileName, index, postSnippet) {
    const snippetLower = (postSnippet || '').toLowerCase();

    // Contextual pools based on detected content topic
    if (snippetLower.includes('marketing') || snippetLower.includes('seo') || snippetLower.includes('agency')) {
      const mktPool = [
        "Crucial marketing insights! Organic reach and strategic consistency make all the difference 🎯",
        "Great marketing strategy breakdown! Applying this approach right away 🚀",
        "Data-backed marketing that actually drives authentic results. Top notch! 👏",
        "Very valuable digital marketing advice! Thanks for sharing this breakdown 🙌",
        "Super insightful! Scaling visibility organically is the most sustainable way ⭐",
        "Brilliant perspective on marketing! Looking forward to more insights like this 🔥"
      ];
      return mktPool[index % mktPool.length];
    }

    if (snippetLower.includes('business') || snippetLower.includes('growth') || snippetLower.includes('sales') || snippetLower.includes('entrepreneur')) {
      const bizPool = [
        "Key takeaways for business growth and scaling! Great explanation 📈",
        "Smart business strategy! Consistent execution is everything 💯",
        "Practical business advice that actually works in the real market! Thanks for posting 💡",
        "Solid insights for modern entrepreneurs and businesses looking to grow 🚀",
        "Very relevant point for businesses looking to scale their reach effectively ⭐",
        "Valuable breakdown! Actionable advice every business owner needs to hear 🙌"
      ];
      return bizPool[index % bizPool.length];
    }

    if (snippetLower.includes('reel') || snippetLower.includes('video') || snippetLower.includes('watch')) {
      const videoPool = [
        "Brilliant reel! Loved the way this was presented and explained 🔥",
        "Great video! Spot on point and super engaging 👏",
        "Amazing reel, saving this one for reference! 📌",
        "Top quality content as always, very inspiring work ⭐",
        "Love the energy and clear explanation in this reel! Keep it up 🙌",
        "Really well put together reel, highly relevant! 💯"
      ];
      return videoPool[index % videoPool.length];
    }

    // High quality versatile authentic comments
    const generalPool = [
      "Really insightful content! Thanks for sharing this perspective 👍",
      "Brilliant post, loved the way this was explained! 🔥",
      "Spot on point! Highly relevant for anyone in this space 💯",
      "Super helpful tips, appreciate the detailed breakdown! 👏",
      "Top quality insights as always, keep up the great work! 🚀",
      "Completely agree with this approach, works wonders! ⭐",
      "Amazing breakdown, bookmarking this for reference! 📌",
      "Great insights! This is exactly what was needed 🙌",
      "Incredible value in this post, thanks for sharing! 💡",
      "Very well presented and actionable insights! 🎯",
      "Outstanding work, always love your updates! 👍",
      "Solid advice as always, highly recommend this! 📈"
    ];

    return generalPool[index % generalPool.length];
  }

  // Find Comment Box / Editor on Post or Reel (supports both Reels drawer and Feed posts)
  async function findCommentEditor() {
    for (let attempt = 0; attempt < 18; attempt++) {
      // 1. Check if comment input is already visible and active
      let editors = Array.from(document.querySelectorAll('div[contenteditable="true"][role="textbox"], div[contenteditable="true"]'));
      let commentEditor = editors.find(ed => {
        const aria = (ed.getAttribute('aria-label') || '').toLowerCase();
        const placeholder = (ed.getAttribute('data-placeholder') || '').toLowerCase();
        return (
          aria.includes('comment') ||
          aria.includes('write a comment') ||
          aria.includes('write a public comment') ||
          aria.includes('टिप्पणी') ||
          placeholder.includes('comment') ||
          placeholder.includes('टिप्पणी')
        );
      });

      if (commentEditor) return commentEditor;

      // 2. On Facebook Reels: click the "Comment" icon in the right-side reel action bar to open comments
      const allButtons = Array.from(document.querySelectorAll('div[role="button"], button'));
      const commentTrigger = allButtons.find(b => {
        const aria = (b.getAttribute('aria-label') || '').toLowerCase();
        const txt = (b.innerText || '').toLowerCase().trim();
        return (
          aria === 'comment' ||
          aria === 'leave a comment' ||
          aria === 'view comments' ||
          aria.includes('comment') ||
          aria.includes('टिप्पणी') ||
          txt === 'comment' ||
          txt === 'टिप्पणी'
        );
      });

      if (commentTrigger) {
        console.log('💬 WSA: Clicking comment trigger to expand comments panel...', commentTrigger);
        commentTrigger.click();
        await sleep(1500);
      }

      // Check again after clicking trigger
      editors = Array.from(document.querySelectorAll('div[contenteditable="true"]'));
      commentEditor = editors.find(ed => {
        const aria = (ed.getAttribute('aria-label') || '').toLowerCase();
        return aria.includes('comment') || aria.includes('write') || aria.includes('टिप्पणी');
      });

      if (commentEditor) return commentEditor;

      await sleep(800);
    }

    // Fallback: Pick last contenteditable on page that isn't a post creator
    const fallbackEditors = Array.from(document.querySelectorAll('div[contenteditable="true"]'));
    return fallbackEditors.length > 0 ? fallbackEditors[fallbackEditors.length - 1] : null;
  }

  // Submit Facebook Comment via Enter key & Send button fallback
  async function submitFacebookComment(editor) {
    if (!editor) return false;
    editor.focus();
    await sleep(400);

    // 1. Look for Send / Submit button near editor
    const parentContainer = editor.closest('form') || editor.closest('div[role="presentation"]') || editor.parentElement?.parentElement;
    if (parentContainer) {
      const sendButtons = Array.from(parentContainer.querySelectorAll('div[role="button"], button'));
      const sendBtn = sendButtons.find(b => {
        const aria = (b.getAttribute('aria-label') || '').toLowerCase();
        return aria === 'comment' || aria === 'send' || aria.includes('submit') || aria.includes('post');
      });
      if (sendBtn) {
        console.log('🚀 WSA: Clicking comment send button:', sendBtn);
        sendBtn.click();
        return true;
      }
    }

    // 2. Dispatch Enter KeyboardEvent sequence
    console.log('⌨️ WSA: Dispatching Enter key sequence to submit comment...');
    editor.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true
    }));
    editor.dispatchEvent(new KeyboardEvent('keypress', {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true
    }));
    editor.dispatchEvent(new KeyboardEvent('keyup', {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true
    }));

    return true;
  }

  // Main Auto-Like & Auto-Comment execution flow for a profile
  async function executeAutoLikeTask(task) {
    updateHud(`🔄 Checking author identity for "${task.profile_name}"...`, 'SWITCHING', '#3b82f6');
    await switchProfileIfNeeded({ sender_name: task.profile_name }, null);
    await sleep(1500);

    // Initial human browse scroll
    window.scrollBy({ top: 160, behavior: 'smooth' });
    await sleep(1200);

    // 1. Auto-Like Action (if enabled)
    let likeStatusText = '';
    let isAlreadyLiked = false;
    if (task.enable_like !== false) {
      updateHud(`👍 Locating & clicking Like button...`, 'LIKING', '#3b82f6');
      const likeResult = await findAndClickLikeButton();
      isAlreadyLiked = !!likeResult.alreadyLiked;
      likeStatusText = isAlreadyLiked ? 'Already Liked 👍' : 'Liked Successfully 👍';
      await sleep(1200);
    }

    // 2. Auto-Comment Action (if enabled)
    let commentSubmitted = false;
    if (task.enable_comment !== false) {
      const tailoredComment = generateContextualComment(task.profile_name, task.index, task.post_snippet);
      console.log(`💬 WSA: Generated contextual comment for "${task.profile_name}": "${tailoredComment}"`);

      updateHud(`💬 Finding comment box to paste tailored comment...`, 'COMMENTING', '#3b82f6');
      const commentEditor = await findCommentEditor();

      if (commentEditor) {
        console.log('✅ WSA: Comment box located:', commentEditor);
        commentEditor.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await sleep(800);

        // Paste comment into editor
        await insertTextIntoEditor(commentEditor, tailoredComment);
        console.log('✅ WSA: Comment pasted successfully into box.');

        // User Requirement: 30-45 sec me submit hoga ... time change hota rahe har baar
        const submitDelaySeconds = Math.floor(Math.random() * (45 - 30 + 1)) + 30; // 30 to 45 seconds dynamic delay
        console.log(`⏱️ WSA: Comment will submit in ${submitDelaySeconds}s with natural human scrolling...`);

        // Continuous natural human scrolling during 30-45s wait
        await simulateHumanScrollCadence(submitDelaySeconds, (remSec, totalSec) => {
          const pct = Math.round(((totalSec - remSec) / totalSec) * 100);
          updateHud(
            `${likeStatusText ? `<b>${likeStatusText}</b> | ` : ''}💬 Comment: <i>"${tailoredComment.slice(0, 32)}..."</i><br>` +
            `⏳ Natural human review & scroll: <b>${remSec}s remaining</b>... (${totalSec}s dynamic submit delay)`,
            `${pct}%`,
            '#3b82f6'
          );
        });

        // Submit comment after 30-45s!
        updateHud(`🚀 Submitting comment on Facebook...`, 'SUBMITTING', '#10b981');
        await submitFacebookComment(commentEditor);
        commentSubmitted = true;
        console.log('✅ WSA: Comment submitted successfully after dynamic wait!');
        await sleep(3500);
      } else {
        console.warn('⚠️ WSA: Comment editor not found, executing natural scroll fallback.');
        const fallbackWait = Math.floor(Math.random() * (35 - 25 + 1)) + 25;
        await simulateHumanScrollCadence(fallbackWait, (remSec, totalSec) => {
          updateHud(`⏳ Natural scroll: <b>${remSec}s remaining</b>...`, `${totalSec - remSec}s`, '#3b82f6');
        });
      }
    } else {
      // If only Like was enabled: 20-30s human scroll
      const likeDuration = Math.floor(Math.random() * (30 - 20 + 1)) + 20;
      await simulateHumanScrollCadence(likeDuration, (remSec, totalSec) => {
        updateHud(
          `<b>${likeStatusText}</b> as <i>${task.profile_name}</i> (${task.index}/${task.total})<br>` +
          `⏳ Natural scrolling & browsing: <b>${remSec}s remaining</b>... Tab will close automatically.`,
          `${Math.round(((totalSec - remSec) / totalSec) * 100)}%`,
          '#10b981'
        );
      });
    }

    updateHud(`✅ Completed for "${task.profile_name}"! Tab closing in 3s...`, 'DONE', '#10b981');
    await sleep(2500);

    chrome.runtime.sendMessage({
      action: 'LIKE_TASK_COMPLETED',
      result: {
        success: true,
        profile_name: task.profile_name,
        already_liked: isAlreadyLiked,
        commented: commentSubmitted
      }
    });
  }

  // Main automated flow
  async function executeGroupShare(task) {
    updateHud(`🎯 Checking sender identity for "${task.sender_name}"...`);
    // Attempt profile switch on group feed if switcher is present
    await switchProfileIfNeeded(task, null);

    let dialog = await findPostDialog(3);

    if (!dialog) {
      updateHud('1️⃣ Locating "Write something..." box...');
      const composerTrigger = await findComposerTrigger();

      if (!composerTrigger) {
        throw new Error('Could not find group composer trigger ("Write something..."). You may need to join the group or switch profile.');
      }

      updateHud('2️⃣ Opening post dialog...');
      composerTrigger.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(600);
      composerTrigger.click();

      updateHud('3️⃣ Waiting for modal dialog...');
      dialog = await findPostDialog(20);
      if (!dialog) {
        throw new Error('Post creation dialog did not open.');
      }
    } else {
      updateHud('3️⃣ Modal dialog already open, proceeding...');
    }

    // Check & switch identity inside the open post modal dialog
    updateHud(`🔄 Verifying author identity inside post modal...`);
    const didSwitchInDialog = await switchProfileIfNeeded(task, dialog);
    if (didSwitchInDialog) {
      // Re-acquire dialog reference if switching caused re-render
      dialog = (await findPostDialog(10)) || dialog;
      await sleep(800);
    }

    updateHud('4️⃣ Locating text editor inside dialog...');
    const editor = await findEditor(dialog);
    if (!editor) {
      throw new Error('Could not find contenteditable editor inside post dialog.');
    }

    // 1 Keyword before the link with visible gap, keeping link 100% intact
    const chosenKeyword = getViralKeyword();
    updateHud(`5️⃣ Setting up: Caption + Keyword ("${chosenKeyword}") + Gap + Intact Link...`);

    const fullFormattedContent = buildFormattedPostText(task.caption, chosenKeyword, task.post_url);
    await insertTextIntoEditor(editor, fullFormattedContent);
    console.log('✅ WSA: Post content filled with keyword, gap and intact link:\n' + fullFormattedContent);

    // Active Preview Detection & Human Cadence Loop
    // User Requirement: Preview aane ke baad hi post button click ho, aur minimum 15s wait rahe!
    let previewDetected = false;
    let previewDetails = '';
    const maxWaitSeconds = 45;
    let elapsedSeconds = 0;

    updateHud('⏳ <b>Waiting for Reel Preview Card:</b> Facebook is scraping video thumbnail...', 'FETCHING', '#3b82f6');

    while (elapsedSeconds < maxWaitSeconds) {
      elapsedSeconds++;

      // Check if preview card appeared in dialog
      if (!previewDetected) {
        const previewCheck = detectFacebookPreviewCard(dialog);
        if (previewCheck.detected) {
          previewDetected = true;
          previewDetails = previewCheck.details;
          console.log(`🎯 WSA: Facebook Reel preview card verified: ${previewDetails}`);
        }
      }

      // Check if minimum 15 seconds have passed AND preview is detected
      if (elapsedSeconds >= 15 && previewDetected) {
        updateHud(`✅ <b>Preview Ready!</b> ${previewDetails}<br><small style="color:#94a3b8;">Natural human pause before clicking Post...</small>`, 'READY', '#10b981');
        await sleep(2500);
        break;
      }

      // Halfway simulation: simulate human reading / cursor focus check
      if (elapsedSeconds % 7 === 0) {
        try {
          if (editor) editor.focus();
        } catch (e) {}
      }

      const statusMsg = previewDetected
        ? `✅ Preview verified! Human safety wait: ${Math.max(0, 15 - elapsedSeconds)}s remaining...`
        : `⏳ Waiting for Reel preview card (${elapsedSeconds}s / max 45s)...`;

      updateHud(
        `${statusMsg}<br><span style="font-size:11px; color:#94a3b8;">Anti-Bot Human Simulation Active</span>`,
        `${elapsedSeconds}s`,
        previewDetected ? '#10b981' : '#3b82f6'
      );

      await sleep(1000);
    }

    if (!previewDetected) {
      console.warn('⚠️ WSA: Preview card took longer than 45s. Proceeding with Post button check.');
    }

    updateHud('6️⃣ Locating active "Post" button...');
    const currentDialog = document.querySelector('div[role="dialog"]') || dialog;
    const postBtn = await findPostButton(currentDialog);

    // Snapshot existing posts & check pre-approval before clicking
    const modalTextBefore = (currentDialog ? currentDialog.innerText : '').toLowerCase();
    const btnLabelBefore = (postBtn ? (postBtn.innerText || postBtn.getAttribute('aria-label') || '') : '').toLowerCase();
    const preApprovalRequired = (
      modalTextBefore.includes('require admin approval') ||
      modalTextBefore.includes('requires admin approval') ||
      modalTextBefore.includes('must be approved by an admin') ||
      modalTextBefore.includes('admin must approve') ||
      modalTextBefore.includes('participant approval') ||
      modalTextBefore.includes('submit for approval') ||
      modalTextBefore.includes('approval required') ||
      btnLabelBefore.includes('submit')
    );

    const existingPostUrls = new Set();
    document.querySelectorAll('a[href*="/posts/"], a[href*="/permalink/"], a[href*="/reel/"]').forEach(a => {
      const clean = (a.href || '').split('?')[0];
      if (clean) existingPostUrls.add(clean);
    });

    let autoClickedAndClosed = false;
    if (postBtn) {
      updateHud('🚀 Auto-Clicking Post Button (Zero-Click!)...');
      postBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(500);
      try {
        postBtn.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
      } catch (e) {}
      postBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      try {
        postBtn.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, view: window }));
      } catch (e) {}
      postBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      postBtn.click();

      // Check if dialog submits and closes within 6 seconds
      for (let w = 0; w < 12; w++) {
        await sleep(500);
        if (!document.querySelector('div[role="dialog"]')) {
          autoClickedAndClosed = true;
          break;
        }
      }
    }

    if (!autoClickedAndClosed) {
      // Auto-click did not close the modal or postBtn wasn't available
      // DO NOT close tab! Enter Manual Post Assist mode to let user click and extension detect outcome
      const diagReason = diagnosePostButtonFailure(currentDialog);
      console.warn('⚠️ WSA: Auto-click could not submit dialog. Entering Manual Assist. Reason:', diagReason);
      await handleManualPostAssist(task, existingPostUrls, preApprovalRequired, diagReason);
      return;
    }

    updateHud('7️⃣ Detecting publication & capturing permalink...');
    const outcome = await detectOutcomeAndPermalink(task, existingPostUrls, preApprovalRequired);

    if (outcome.status === 'pending_approval') {
      updateHud(`🟡 Share Recorded! Pending Admin Approval. Tab closing in 4s...`, 'PENDING', '#eab308');
    } else {
      const linkMsg = outcome.postUrl
        ? `<br><a href="${outcome.postUrl}" target="_blank" style="color:#93c5fd; text-decoration:underline; font-size:11.5px; word-break:break-all;">${outcome.postUrl}</a>`
        : '';
      updateHud(`✅ Successfully Shared Live!${linkMsg}<br>Tab closing in 4s...`, 'SUCCESS', '#10b981');
    }

    // Report back to background service worker
    chrome.runtime.sendMessage({
      action: 'TASK_COMPLETED',
      result: {
        queue_id: task.id,
        status: outcome.status,
        shared_post_url: outcome.postUrl,
        error_message: null
      }
    });
  }

  // Start initialization
  init();
})();
